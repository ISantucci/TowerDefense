using UnityEngine;

public class EventQueueManager : MonoBehaviour
{
    public static EventQueueManager I { get; private set; }

   QueueTF<GameplayEvent> queue = new QueueTF<GameplayEvent>();

    void Awake()
    {
        if (I != null && I != this)
        {
            Destroy(gameObject);
            return;
        }

        I = this;
        DontDestroyOnLoad(gameObject);

        // arrancamos con una cola vac�a
        queue.InitializeFromArray(null);
    }

    public static void Enqueue(GameplayEvent e)
    {
        if (I == null)
        {
            Debug.LogWarning("[EventQueueManager] No instance, evento ignorado.");
            return;
        }

        I.queue.Enqueue(e);
    }

    void Update()
    {
        
        while (!queue.IsEmpty())
        {
            var evt = queue.Dequeue();
            ProcessEvent(evt);
        }
    }

    void ProcessEvent(GameplayEvent evt)
    {
        switch (evt.type)
        {
            case GameplayEventType.EnemyDied:
                // despu�s lo llenamos cuando migremos EnemyTD
                break;

            case GameplayEventType.TowerBuilt:
                break;

            case GameplayEventType.WaveStarted:
                break;

            case GameplayEventType.WaveEnded:
                break;

            case GameplayEventType.LifeLost:
                break;

            case GameplayEventType.LevelWon:
                break;

            case GameplayEventType.LevelLost:
                break;

            default:
                break;
        }
    }
}
