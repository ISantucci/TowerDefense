// Assets/Scripts/Enemies/EnemyMovement.cs
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    [Header("Movimiento")]
    public float moveSpeed = 2.5f;

    // ruta inyectada por el spawner (Dijkstra)
    List<Transform> route;   // puntos en orden
    int currentIndex = 0;
    Transform target;

    // Slow temporal (multiplicador sobre moveSpeed)
    float currentMultiplier = 1f;
    float slowTimer = 0f;

    // === PROPIEDADES SOLO LECTURA PARA OTRAS CLASES (EnemyProgress, etc.) ===
    public IReadOnlyList<Transform> Route => route;
    public int CurrentIndex => currentIndex;
    public float CurrentSpeedMultiplier => currentMultiplier;

    // === API: el spawner te setea la ruta antes de empezar a mover ===
    public void SetRoute(IReadOnlyList<Transform> points)
    {
        if (points == null || points.Count == 0)
        {
            enabled = false;
            return;
        }

        // copiamos a lista mutable interna
        route = new List<Transform>(points);
        currentIndex = 0;
        target = route[currentIndex];

        // ajustar Y
        var p = transform.position;
        transform.position = new Vector3(p.x, 0.5f, p.z);
    }

    /// <summary>Aplica un multiplicador de velocidad (0.5 = mitad) durante seconds. Un slow nuevo reemplaza al anterior.</summary>
    public void ApplySlow(float multiplier, float seconds)
    {
        if (seconds <= 0f) return;
        currentMultiplier = Mathf.Clamp(multiplier, 0f, 1f);
        slowTimer = seconds;
    }

    /// <summary>
    /// Empuja al enemigo hacia atrás por su ruta (hacia el waypoint anterior) una distancia dada.
    /// Si pasa el waypoint anterior, retrocede el índice y re-apunta; nunca baja del índice 0.
    /// </summary>
    public void Knockback(float distance)
    {
        if (route == null || route.Count == 0 || distance <= 0f) return;

        float remaining = distance;

        while (remaining > 0f && currentIndex > 0)
        {
            Transform prev = route[currentIndex - 1];
            if (prev == null) break;

            Vector3 toPrev = prev.position - transform.position;
            float dist = toPrev.magnitude;

            if (remaining < dist)
            {
                transform.position += toPrev.normalized * remaining;
                remaining = 0f;
            }
            else
            {
                // Pasa el waypoint anterior: lo alcanza y sigue retrocediendo desde ahí.
                transform.position = prev.position;
                remaining -= dist;
                currentIndex--;
                target = route[currentIndex];
            }
        }

        // Refrescar el progreso en el ABB inmediatamente.
        var prog = GetComponent<EnemyProgress>();
        if (prog != null) prog.Recalculate();
    }

    void Update()
    {
        if (route == null || target == null) return;

        // Timer del slow
        if (slowTimer > 0f)
        {
            slowTimer -= Time.deltaTime;
            if (slowTimer <= 0f)
            {
                slowTimer = 0f;
                currentMultiplier = 1f;
            }
        }

        Vector3 dir = (target.position - transform.position);
        float speed = moveSpeed * currentMultiplier;
        float step = speed * Time.deltaTime;

        if (dir.magnitude <= step)
        {
            transform.position = target.position;
            currentIndex++;

            if (currentIndex >= route.Count)
            {
                var e = GetComponent<EnemyTD>();
                if (e != null) e.ReachEnd();
                else Destroy(gameObject);

                enabled = false;
                return;
            }

            target = route[currentIndex];
        }
        else
        {
            transform.position += dir.normalized * step;
        }
    }
}
