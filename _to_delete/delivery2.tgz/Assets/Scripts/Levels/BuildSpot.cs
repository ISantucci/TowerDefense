using UnityEngine;

/// <summary>
/// Marcador de un lugar de construcción. Sabe su celda, si está ocupado y cómo iluminarse.
/// La ocupación se decide mirando Tower.Instances (no guarda estado que se pueda desincronizar con undo/sell).
/// </summary>
public class BuildSpot : MonoBehaviour
{
    public Vector2Int cell;
    public Vector3 worldPosition;

    MeshRenderer pad;
    GameObject ring;
    Material normalMat;
    Material availableMat;

    public void Init(Vector2Int cell, Vector3 world, MeshRenderer padRenderer, GameObject ringObject, Material normal, Material available)
    {
        this.cell = cell;
        worldPosition = world;
        pad = padRenderer;
        ring = ringObject;
        normalMat = normal;
        availableMat = available;
    }

    /// <summary>Ocupado si hay una torre a menos de media celda del centro.</summary>
    public bool IsOccupied
    {
        get
        {
            var list = Tower.Instances;
            for (int i = 0; i < list.Count; i++)
            {
                var t = list[i];
                if (t == null) continue;
                Vector3 d = t.transform.position - worldPosition;
                d.y = 0f;
                if (d.sqrMagnitude < 0.25f) return true;
            }
            return false;
        }
    }

    /// <summary>0 = normal, 1 = disponible (hay torre seleccionada), 2 = bajo el cursor.</summary>
    public void SetHighlight(int state)
    {
        bool occupied = IsOccupied;
        if (pad != null) pad.sharedMaterial = (state >= 1 && !occupied) ? availableMat : normalMat;
        if (ring != null) ring.SetActive(state == 2 && !occupied);
    }
}

/// <summary>Rotación/pulso/vaivén simple para adornos (portal, bandera, cristales).</summary>
public class SimpleSpin : MonoBehaviour
{
    public Vector3 axis = Vector3.up;
    public float degreesPerSecond = 30f;
    public float pulse = 0f;
    public float swayDegrees = 0f;

    Vector3 baseScale;
    Quaternion baseRot;
    float phase;

    void Start()
    {
        baseScale = transform.localScale;
        baseRot = transform.localRotation;
        phase = Random.value * 6.28f;
    }

    void Update()
    {
        if (degreesPerSecond != 0f)
            transform.Rotate(axis, degreesPerSecond * Time.deltaTime, Space.Self);

        if (pulse > 0f)
            transform.localScale = baseScale * (1f + Mathf.Sin(Time.time * 3f + phase) * pulse);

        if (swayDegrees > 0f)
            transform.localRotation = baseRot * Quaternion.AngleAxis(Mathf.Sin(Time.time * 2.2f + phase) * swayDegrees, axis);
    }
}
