using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Esquina superior derecha: velocidad (x1/x2/x3 cíclico), pausa (botón o tecla P) con overlay
/// de pantalla completa y slider de volumen (ProceduralAudio.MasterVolume vía UiAudioBridge).
/// </summary>
public class GameSpeedUI : MonoBehaviour
{
    static readonly float[] Speeds = { 1f, 2f, 3f };

    LevelRuntime rt;
    RectTransform root;

    Button speedButton;
    Text speedLabel;
    Button pauseButton;
    Text pauseLabel;
    Slider volumeSlider;

    RectTransform overlay;
    bool overlayShown;
    float shownSpeed = -1f;

    public static GameSpeedUI Create(LevelRuntime rt, RectTransform root)
    {
        if (rt == null || root == null) return null;
        var container = UiKit.CreateRect("GameSpeedUI", root);
        UiKit.SetFullscreen(container);
        var ui = container.gameObject.AddComponent<GameSpeedUI>();
        ui.Init(rt, root);
        return ui;
    }

    void Init(LevelRuntime runtime, RectTransform parent)
    {
        rt = runtime;
        root = parent;
        BuildPanel();
        BuildOverlay();
        RefreshSpeedLabel();
    }

    // ───────────────────────── construcción ─────────────────────────

    void BuildPanel()
    {
        var panel = UiKit.CreatePanel("SpeedPanel", transform, UiKit.PanelColor, 2f);
        var p = panel.rectTransform;
        UiKit.Place(p, UiKit.TopRight, UiKit.TopRight, new Vector2(-12f, -12f), new Vector2(300f, 84f));

        speedButton = UiKit.CreateButton("SpeedButton", p, "x1", OnSpeedClicked, UiKit.ButtonColor, 16, new Vector2(66f, 32f));
        UiKit.Place(speedButton.GetComponent<RectTransform>(), UiKit.TopRight, UiKit.TopRight, new Vector2(-8f, -8f), new Vector2(66f, 32f));
        speedLabel = UiKit.ButtonLabel(speedButton);

        pauseButton = UiKit.CreateButton("PauseButton", p, "II  Pausa", OnPauseClicked, UiKit.ButtonColor, 15, new Vector2(112f, 32f));
        UiKit.Place(pauseButton.GetComponent<RectTransform>(), UiKit.TopRight, UiKit.TopRight, new Vector2(-82f, -8f), new Vector2(112f, 32f));
        pauseLabel = UiKit.ButtonLabel(pauseButton);

        var hint = UiKit.CreateText("Hint", p, "P", 12, UiKit.MutedText, TextAnchor.MiddleLeft, FontStyle.Bold);
        UiKit.Place(hint.rectTransform, UiKit.TopLeft, UiKit.TopLeft, new Vector2(10f, -8f), new Vector2(80f, 32f));
        hint.text = "P = pausa";

        var volLabel = UiKit.CreateText("VolumeLabel", p, "Volumen", 14, UiKit.MutedText, TextAnchor.MiddleLeft);
        UiKit.Place(volLabel.rectTransform, UiKit.TopLeft, UiKit.TopLeft, new Vector2(10f, -48f), new Vector2(70f, 26f));

        volumeSlider = UiKit.CreateSlider("VolumeSlider", p, UiAudioBridge.Volume, OnVolumeChanged);
        UiKit.Place(volumeSlider.GetComponent<RectTransform>(), UiKit.TopLeft, UiKit.TopLeft, new Vector2(84f, -48f), new Vector2(206f, 26f));
    }

    void BuildOverlay()
    {
        var img = UiKit.CreateImage("PauseOverlay", root, new Color(0f, 0f, 0f, 0.6f), true);
        overlay = img.rectTransform;
        UiKit.SetFullscreen(overlay);

        var panel = UiKit.CreatePanel("PausePanel", overlay, UiKit.PanelStrong, 2f);
        UiKit.Place(panel.rectTransform, UiKit.Center, UiKit.Center, Vector2.zero, new Vector2(380f, 350f));

        var v = panel.gameObject.AddComponent<VerticalLayoutGroup>();
        v.padding = new RectOffset(24, 24, 22, 22);
        v.spacing = 10f;
        v.childAlignment = TextAnchor.UpperCenter;
        v.childControlWidth = true;
        v.childControlHeight = true;
        v.childForceExpandWidth = true;
        v.childForceExpandHeight = false;

        var title = UiKit.CreateText("Title", panel.transform, "PAUSA", 44, UiKit.Gold, TextAnchor.MiddleCenter, FontStyle.Bold);
        UiKit.AddShadow(title.gameObject, new Color(0f, 0f, 0f, 0.8f), new Vector2(2f, -2f));
        UiKit.Layout(title.gameObject, 0f, 60f);

        AddOverlayButton(panel.transform, "Continuar", UiKit.ButtonAccent, OnResume);
        AddOverlayButton(panel.transform, "Reiniciar nivel", UiKit.ButtonColor, OnRestart);
        AddOverlayButton(panel.transform, "Elegir nivel", UiKit.ButtonColor, OnLevelSelector);
        AddOverlayButton(panel.transform, "Menú", UiKit.ButtonColor, OnMainMenu);

        overlay.gameObject.SetActive(false);
    }

    void AddOverlayButton(Transform parent, string label, Color color, UnityEngine.Events.UnityAction action)
    {
        var b = UiKit.CreateButton("Btn_" + label, parent, label, action, color, 18, new Vector2(300f, 46f));
        UiKit.Layout(b.gameObject, 0f, 46f);
    }

    // ───────────────────────── acciones ─────────────────────────

    void OnSpeedClicked()
    {
        UiKit.ClearSelection();
        if (rt == null) return;
        float current = rt.GameSpeed;
        int idx = 0;
        for (int i = 0; i < Speeds.Length; i++)
            if (Mathf.Abs(Speeds[i] - current) < 0.01f) { idx = i; break; }
        float next = Speeds[(idx + 1) % Speeds.Length];
        rt.SetGameSpeed(next);
        RefreshSpeedLabel();
    }

    void OnPauseClicked()
    {
        UiKit.ClearSelection();
        if (rt == null || rt.IsFinished) return;
        rt.TogglePause();
    }

    void OnResume()
    {
        UiKit.ClearSelection();
        if (rt != null) rt.SetPaused(false);
    }

    void OnRestart()
    {
        UiKit.ClearSelection();
        var level = rt != null ? rt.Level : LevelCatalog.Selected;
        if (level == null) level = LevelCatalog.First;
        LevelBootstrap.PlayLevel(level);
    }

    void OnLevelSelector()
    {
        UiKit.ClearSelection();
        LevelBootstrap.GoToLevelSelector();
    }

    void OnMainMenu()
    {
        UiKit.ClearSelection();
        LevelBootstrap.GoToMainMenu();
    }

    void OnVolumeChanged(float v)
    {
        UiAudioBridge.Volume = v;
    }

    void RefreshSpeedLabel()
    {
        if (rt == null || speedLabel == null) return;
        float s = rt.GameSpeed;
        if (Mathf.Approximately(s, shownSpeed)) return;
        shownSpeed = s;
        speedLabel.text = "x" + UiKit.FormatNumber(s);
    }

    // ───────────────────────── update ─────────────────────────

    void Update()
    {
        if (rt == null) return;

        if (!rt.IsFinished && Input.GetKeyDown(KeyCode.P) && !UiKit.IsTyping())
            rt.TogglePause();

        bool paused = rt.IsPaused;
        if (paused != overlayShown)
        {
            overlayShown = paused;
            if (overlay != null)
            {
                overlay.gameObject.SetActive(paused);
                if (paused) overlay.SetAsLastSibling();
            }
            if (pauseLabel != null) pauseLabel.text = paused ? "Continuar" : "II  Pausa";
        }

        RefreshSpeedLabel();
    }
}
