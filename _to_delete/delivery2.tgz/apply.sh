#!/bin/bash
# Aplica el paquete sobre el proyecto: sobreescribe en el lugar (sin borrar/recrear) para que funcione en el mount del owner.
set -u
PKG="$1"; DEST="$2"
cd "$DEST" || exit 1
n_new=0; n_upd=0
tar tzf "$PKG" | grep -v '/$' | grep '^Assets/' | while read -r f; do
  d=$(dirname "$f"); mkdir -p "$d"
  if [ -e "$f" ]; then tar xzOf "$PKG" "$f" > "$f" && echo "upd $f"; else tar xzf "$PKG" "$f" && echo "new $f"; fi
done
