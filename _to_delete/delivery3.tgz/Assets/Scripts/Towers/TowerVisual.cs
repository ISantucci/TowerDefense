using System.Collections.Generic;
using UnityEngine;

/// <summary>Paleta compartida por torres, íconos y HUD: color por familia (juego de origen) y por tipo de ataque.</summary>
public static class DefensePalette
{
    public static Color Family(DefenseSource s)
    {
        switch (s)
        {
            case DefenseSource.CoC_Home: return new Color(0.96f, 0.76f, 0.22f);
            case DefenseSource.CoC_Builder: return new Color(0.88f, 0.48f, 0.20f);
            case DefenseSource.CoC_Capital: return new Color(0.62f, 0.38f, 0.90f);
            case DefenseSource.CR: return new Color(0.30f, 0.58f, 0.98f);
            case DefenseSource.BoomBeach: return new Color(0.25f, 0.78f, 0.48f);
            default: return new Color(0.25f, 0.72f, 0.72f);
        }
    }

    public static Color Attack(AttackType a)
    {
        switch (a)
        {
            case AttackType.Splash: return new Color(1.0f, 0.55f, 0.15f);
            case AttackType.MultiTarget: return new Color(0.35f, 0.95f, 0.95f);
            case AttackType.Burst: return new Color(1.0f, 0.92f, 0.30f);
            case AttackType.Beam: return new Color(1.0f, 0.25f, 0.25f);
            case AttackType.Chain: return new Color(0.45f, 0.65f, 1.0f);
            case AttackType.Push: return new Color(0.70f, 0.90f, 1.0f);
            case AttackType.SingleTarget: return new Color(0.95f, 0.95f, 0.95f);
            default: return new Color(0.6f, 0.6f, 0.6f);
        }
    }

    public static string FamilyName(DefenseSource s)
    {
        switch (s)
        {
            case DefenseSource.CoC_Home: return "Clash of Clans · Aldea";
            case DefenseSource.CoC_Builder: return "Clash of Clans · Taller";
            case DefenseSource.CoC_Capital: return "Clash of Clans · Capital";
            case DefenseSource.CR: return "Clash Royale";
            case DefenseSource.BoomBeach: return "Boom Beach";
            default: return "Original";
        }
    }

    public static string AttackName(AttackType a)
    {
        switch (a)
        {
            case AttackType.SingleTarget: return "Un objetivo";
            case AttackType.Splash: return "Área";
            case AttackType.MultiTarget: return "Multiobjetivo";
            case AttackType.Burst: return "Ráfaga";
            case AttackType.Beam: return "Rayo (rampa)";
            case AttackType.Chain: return "Cadena";
            case AttackType.Push: return "Empuje";
            case AttackType.Pull: return "Atracción";
            case AttackType.Spawner: return "Genera tropas";
            case AttackType.Support: return "Soporte";
            case AttackType.Trap: return "Trampa";
        }
        return a.ToString();
    }

    public static string TargetsName(TargetLayer t)
    {
        if (t == TargetLayer.Both) return "Tierra y aire";
        if (t == TargetLayer.Air) return "Sólo aire";
        if (t == TargetLayer.Ground) return "Sólo tierra";
        return "—";
    }
}

/// <summary>
/// Apariencia de una torre construida: tinte por familia sobre el modelo compartido, emblema flotante
/// con el color del tipo de ataque y escala por costo. No toca colliders ni lógica.
/// </summary>
public class TowerVisual : MonoBehaviour
{
    public Color familyColor;
    public Color attackColor;
    Transform emblem;
    Transform muzzleMarker;

    public static void Apply(Tower tower, TowerData data)
    {
        if (tower == null || data == null) return;
        var v = tower.GetComponent<TowerVisual>();
        if (v == null) v = tower.gameObject.AddComponent<TowerVisual>();
        v.Configure(tower, data);
    }

    void Configure(Tower tower, TowerData data)
    {
        familyColor = DefensePalette.Family(data.source);
        attackColor = DefensePalette.Attack(data.attackType);

        // 1) tinte del modelo (materiales instanciados por torre)
        var renderers = new List<Renderer>();
        GetComponentsInChildren<Renderer>(true, renderers);
        Color tint = Color.Lerp(Color.white, familyColor, data.source == DefenseSource.Original ? 0.15f : 0.55f);
        foreach (var r in renderers)
        {
            if (r == null || r is LineRenderer) continue;
            var mats = r.materials;
            for (int i = 0; i < mats.Length; i++)
            {
                if (mats[i] != null && mats[i].HasProperty("_Color"))
                    mats[i].color = mats[i].color * tint;
            }
        }

        // 2) escala por tier de costo (40..600 → 0.9..1.25)
        float tier = Mathf.InverseLerp(40f, 600f, data.cost);
        float scale = Mathf.Lerp(0.9f, 1.25f, tier);
        transform.localScale = Vector3.one * scale;

        // 3) emblema flotante
        if (emblem == null)
        {
            var e = GameObject.CreatePrimitive(PrimitiveType.Cube);
            e.name = "Emblem";
            var col = e.GetComponent<Collider>();
            if (col != null) Destroy(col);
            e.transform.SetParent(transform, false);
            float top = TopOfModel();
            e.transform.localPosition = new Vector3(0f, top + 0.6f, 0f);
            e.transform.localScale = Vector3.one * 0.28f;
            e.transform.localRotation = Quaternion.Euler(45f, 45f, 0f);
            var mr = e.GetComponent<MeshRenderer>();
            var sh = Shader.Find("Standard");
            var m = sh != null ? new Material(sh) : new Material(Shader.Find("Diffuse"));
            m.color = attackColor;
            m.EnableKeyword("_EMISSION");
            if (m.HasProperty("_EmissionColor")) m.SetColor("_EmissionColor", attackColor * 0.9f);
            mr.sharedMaterial = m;
            mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            var spin = e.AddComponent<SimpleSpin>();
            spin.axis = Vector3.up;
            spin.degreesPerSecond = 60f;
            spin.pulse = 0.12f;
            emblem = e.transform;
        }
    }

    void OnDestroy()
    {
        var renderers = GetComponentsInChildren<Renderer>(true);
        foreach (var r in renderers)
        {
            if (r == null) continue;
            var mats = r.sharedMaterials;
            for (int i = 0; i < mats.Length; i++)
                if (mats[i] != null && mats[i].name.EndsWith("(Instance)")) Destroy(mats[i]);
        }
    }

    /// <summary>Altura aproximada del modelo (en espacio local) para ubicar el emblema.</summary>
    float TopOfModel()
    {
        float top = 1.5f;
        var renderers = GetComponentsInChildren<Renderer>();
        foreach (var r in renderers)
        {
            if (r == null || r is LineRenderer || r.name == "Emblem") continue;
            float y = transform.InverseTransformPoint(r.bounds.max).y;
            if (y > top) top = y;
        }
        return Mathf.Min(top, 4f);
    }
}
