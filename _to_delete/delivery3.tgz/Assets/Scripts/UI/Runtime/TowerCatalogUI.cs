using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Barra inferior con una carta por torre del roster del nivel: ícono procedural, nombre y costo.
/// Hotkeys 1..8, borde dorado en la seleccionada, cartas atenuadas si no alcanza el oro y tooltip al pasar el mouse.
/// </summary>
public class TowerCatalogUI : MonoBehaviour
{
    public const float CardW = 92f;
    public const float CardH = 108f;
    public const float Spacing = 8f;
    public const float PadX = 12f;
    public const float PadY = 8f;
    public const float BarBottom = 8f;
    const int MaxCards = 8;

    class Card
    {
        public TowerData data;
        public RectTransform rect;
        public Image bg;
        public Outline outline;
        public CanvasGroup group;
        public Text costText;
        public Button button;
        public bool selected;
    }

    LevelRuntime rt;

    TowerPlacer placer;   // persistente: se cachea para desuscribirse siempre
    RectTransform root;
    RectTransform bar;
    readonly List<Card> cards = new List<Card>();
    int money;

    RectTransform tooltip;
    Image tooltipStrip;
    Text tipName, tipFamily, tipAttack, tipDps, tipRange, tipSpecial, tipCost;
    Card hoveredCard;

    /// <summary>Altura total que ocupa la barra desde el borde inferior (para ubicar toasts/tooltip encima).</summary>
    public static float BarTop
    {
        get { return BarBottom + CardH + PadY * 2f; }
    }

    public static TowerCatalogUI Create(LevelRuntime rt, RectTransform root)
    {
        if (rt == null || root == null) return null;
        var container = UiKit.CreateRect("TowerCatalogUI", root);
        UiKit.SetFullscreen(container);
        var ui = container.gameObject.AddComponent<TowerCatalogUI>();
        ui.Init(rt, root);
        return ui;
    }

    void Init(LevelRuntime runtime, RectTransform parent)
    {
        rt = runtime;
        root = parent;
        money = GameManager.I != null ? GameManager.I.Money : 0;

        BuildBar();
        BuildTooltip();
        NudgeLegacyButtons();

        GameEvents.MoneyChanged += OnMoneyChanged;
        placer = rt.Placer;
        if (placer != null)
        {
            placer.OnTowerSelected += OnTowerSelected;
            placer.OnSelectionCleared += OnSelectionCleared;
        }

        RefreshAffordability();
        if (rt.Placer != null && rt.Placer.HasSelection) OnTowerSelected(rt.Placer.SelectedTowerId);
    }

    void OnDestroy()
    {
        GameEvents.MoneyChanged -= OnMoneyChanged;
        if (placer != null)
        {
            placer.OnTowerSelected -= OnTowerSelected;
            placer.OnSelectionCleared -= OnSelectionCleared;
        }
    }

    // ───────────────────────── construcción ─────────────────────────

    int CardCount()
    {
        if (rt == null || rt.Roster == null) return 0;
        int n = 0;
        for (int i = 0; i < rt.Roster.Count && n < MaxCards; i++)
            if (rt.Roster[i] != null) n++;
        return n;
    }

    float BarWidth()
    {
        int n = Mathf.Max(1, CardCount());
        return n * CardW + (n - 1) * Spacing + PadX * 2f;
    }

    void BuildBar()
    {
        var panel = UiKit.CreatePanel("CatalogBar", transform, UiKit.PanelColor, 2f);
        bar = panel.rectTransform;
        UiKit.Place(bar, UiKit.BottomCenter, UiKit.BottomCenter, new Vector2(0f, BarBottom), new Vector2(BarWidth(), CardH + PadY * 2f));

        var h = panel.gameObject.AddComponent<HorizontalLayoutGroup>();
        h.padding = new RectOffset((int)PadX, (int)PadX, (int)PadY, (int)PadY);
        h.spacing = Spacing;
        h.childAlignment = TextAnchor.MiddleCenter;
        h.childControlWidth = true;
        h.childControlHeight = true;
        h.childForceExpandWidth = false;
        h.childForceExpandHeight = false;

        var fit = panel.gameObject.AddComponent<ContentSizeFitter>();
        fit.horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
        fit.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        int index = 0;
        for (int i = 0; i < rt.Roster.Count && index < MaxCards; i++)
        {
            var d = rt.Roster[i];
            if (d == null) continue;
            cards.Add(BuildCard(d, index));
            index++;
        }

        if (cards.Count == 0)
        {
            var empty = UiKit.CreateText("Empty", bar, "Sin torres disponibles en este nivel", 14, UiKit.MutedText, TextAnchor.MiddleCenter);
            UiKit.Layout(empty.gameObject, 260f, CardH);
        }
    }

    Card BuildCard(TowerData data, int index)
    {
        var c = new Card();
        c.data = data;

        var img = UiKit.CreateImage("Card_" + data.id, bar, Color.white, true);
        c.bg = img;
        c.rect = img.rectTransform;
        UiKit.Layout(img.gameObject, CardW, CardH);
        c.outline = UiKit.AddOutline(img.gameObject, new Color(1f, 1f, 1f, 0.10f), 2f);
        c.group = UiKit.Group(img.gameObject);

        c.button = img.gameObject.AddComponent<Button>();
        c.button.targetGraphic = img;
        c.button.transition = Selectable.Transition.ColorTint;
        UiKit.SetHoverColors(c.button, UiKit.CardColor);
        TowerData captured = data;
        c.button.onClick.AddListener(() => OnCardClicked(captured));

        var icon = UiKit.CreateImage("Icon", img.transform, Color.white, false);
        icon.sprite = TowerIconFactory.Get(data);
        icon.preserveAspect = true;
        UiKit.Place(icon.rectTransform, UiKit.TopCenter, UiKit.TopCenter, new Vector2(0f, -4f), new Vector2(64f, 64f));

        var hot = UiKit.CreateText("Hotkey", img.transform, (index + 1).ToString(), 11, UiKit.MutedText, TextAnchor.UpperLeft, FontStyle.Bold);
        UiKit.Place(hot.rectTransform, UiKit.TopLeft, UiKit.TopLeft, new Vector2(5f, -3f), new Vector2(18f, 14f));

        var name = UiKit.CreateText("Name", img.transform, data.DisplayName, 12, UiKit.TextColor, TextAnchor.MiddleCenter, FontStyle.Bold);
        var nr = name.rectTransform;
        nr.anchorMin = new Vector2(0f, 0f);
        nr.anchorMax = new Vector2(1f, 0f);
        nr.pivot = new Vector2(0.5f, 0f);
        nr.anchoredPosition = new Vector2(0f, 17f);
        nr.sizeDelta = new Vector2(-6f, 24f);
        UiKit.BestFit(name, 8, 12);

        c.costText = UiKit.CreateText("Cost", img.transform, data.cost + " oro", 13, UiKit.Gold, TextAnchor.MiddleCenter, FontStyle.Bold);
        var cr = c.costText.rectTransform;
        cr.anchorMin = new Vector2(0f, 0f);
        cr.anchorMax = new Vector2(1f, 0f);
        cr.pivot = new Vector2(0.5f, 0f);
        cr.anchoredPosition = new Vector2(0f, 1f);
        cr.sizeDelta = new Vector2(-6f, 16f);
        UiKit.BestFit(c.costText, 9, 13);

        var hover = img.gameObject.AddComponent<UiHoverRelay>();
        Card capturedCard = c;
        hover.onEnter = () => ShowTooltip(capturedCard);
        hover.onExit = () => HideTooltip(capturedCard);
        return c;
    }

    // ───────────────────────── tooltip ─────────────────────────

    void BuildTooltip()
    {
        var panel = UiKit.CreatePanel("Tooltip", transform, UiKit.PanelStrong, 2f, false);
        tooltip = panel.rectTransform;
        UiKit.Place(tooltip, UiKit.BottomCenter, UiKit.BottomCenter, new Vector2(0f, BarTop + 12f), new Vector2(310f, 200f));

        var v = panel.gameObject.AddComponent<VerticalLayoutGroup>();
        v.padding = new RectOffset(12, 12, 10, 10);
        v.spacing = 3f;
        v.childAlignment = TextAnchor.UpperLeft;
        v.childControlWidth = true;
        v.childControlHeight = true;
        v.childForceExpandWidth = true;
        v.childForceExpandHeight = false;

        var fit = panel.gameObject.AddComponent<ContentSizeFitter>();
        fit.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
        fit.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        var group = UiKit.Group(panel.gameObject);
        group.blocksRaycasts = false;
        group.interactable = false;

        tooltipStrip = UiKit.CreateImage("Strip", tooltip, UiKit.Gold, false);
        UiKit.Layout(tooltipStrip.gameObject, 0f, 4f);

        tipName = TooltipLine("Name", 20, UiKit.TextColor, FontStyle.Bold);
        tipFamily = TooltipLine("Family", 13, UiKit.MutedText, FontStyle.Bold);
        tipAttack = TooltipLine("Attack", 14, UiKit.TextColor, FontStyle.Normal);
        tipDps = TooltipLine("Dps", 14, UiKit.TextColor, FontStyle.Normal);
        tipRange = TooltipLine("Range", 14, UiKit.TextColor, FontStyle.Normal);
        tipSpecial = TooltipLine("Special", 13, UiKit.MutedText, FontStyle.Italic);
        tipCost = TooltipLine("Cost", 16, UiKit.Gold, FontStyle.Bold);

        tooltip.gameObject.SetActive(false);
    }

    Text TooltipLine(string name, int size, Color color, FontStyle style)
    {
        var t = UiKit.CreateText(name, tooltip, string.Empty, size, color, TextAnchor.MiddleLeft, style);
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return t;
    }

    void ShowTooltip(Card c)
    {
        if (c == null || c.data == null || tooltip == null) return;
        var d = c.data;
        Color fam = DefensePalette.Family(d.source);

        tooltipStrip.color = fam;
        tipName.text = d.DisplayName;
        tipFamily.text = DefensePalette.FamilyName(d.source);
        tipFamily.color = fam;
        tipAttack.text = "Ataque: " + DefensePalette.AttackName(d.attackType) + "   ·   Objetivos: " + DefensePalette.TargetsName(d.targets);

        if (d.fireRate > 0f)
            tipDps.text = "DPS: " + d.Dps.ToString("F1") + "   (" + d.damage + " de daño cada " + d.fireRate.ToString("0.##") + " s)";
        else
            tipDps.text = "DPS: —";

        string range = "Alcance: " + d.range.ToString("0.#");
        if (d.minRange > 0f) range += "   ·   Alcance mínimo: " + d.minRange.ToString("0.#");
        tipRange.text = range;

        string special = !string.IsNullOrEmpty(d.special) ? d.special : d.description;
        bool hasSpecial = !string.IsNullOrEmpty(special);
        tipSpecial.gameObject.SetActive(hasSpecial);
        tipSpecial.text = hasSpecial ? special : string.Empty;

        tipCost.text = "Costo: " + d.cost + " oro";
        tipCost.color = d.cost <= money ? UiKit.Gold : UiKit.Danger;

        tooltip.gameObject.SetActive(true);
        tooltip.SetAsLastSibling();
        LayoutRebuilder.ForceRebuildLayoutImmediate(tooltip);

        // centrado sobre la carta, sin salirse del canvas
        Vector3 local = root.InverseTransformPoint(c.rect.position);
        float halfRoot = root.rect.width * 0.5f;
        float halfTip = tooltip.rect.width * 0.5f;
        float x = local.x;
        if (halfRoot > halfTip + 8f) x = Mathf.Clamp(x, -halfRoot + halfTip + 8f, halfRoot - halfTip - 8f);
        tooltip.anchoredPosition = new Vector2(x, BarTop + 12f);
        hoveredCard = c;
    }

    void HideTooltip(Card c)
    {
        if (hoveredCard != null && hoveredCard != c) return;
        hoveredCard = null;
        if (tooltip != null) tooltip.gameObject.SetActive(false);
    }

    // ───────────────────────── interacción ─────────────────────────

    void Update()
    {
        if (rt == null || rt.IsPaused || rt.IsFinished) return;
        if (cards.Count == 0 || UiKit.IsTyping()) return;

        for (int i = 0; i < cards.Count && i < MaxCards; i++)
        {
            KeyCode main = (KeyCode)((int)KeyCode.Alpha1 + i);
            KeyCode pad = (KeyCode)((int)KeyCode.Keypad1 + i);
            if (Input.GetKeyDown(main) || Input.GetKeyDown(pad))
            {
                OnCardClicked(cards[i].data);
                break;
            }
        }
    }

    void OnCardClicked(TowerData data)
    {
        UiKit.ClearSelection();
        if (rt == null || rt.Placer == null || data == null) return;
        if (rt.IsPaused) return;

        if (rt.Placer.HasSelection && rt.Placer.SelectedTowerId == data.id)
        {
            rt.Placer.CancelSelection();
            return;
        }
        rt.Placer.SelectTower(data.id);
    }

    void OnTowerSelected(TowerId id)
    {
        foreach (var c in cards) SetSelected(c, c.data != null && c.data.id == id);
    }

    void OnSelectionCleared()
    {
        foreach (var c in cards) SetSelected(c, false);
    }

    void SetSelected(Card c, bool on)
    {
        if (c == null) return;
        c.selected = on;
        if (c.outline != null)
        {
            c.outline.effectColor = on ? UiKit.Gold : new Color(1f, 1f, 1f, 0.10f);
            c.outline.effectDistance = on ? new Vector2(3f, 3f) : new Vector2(2f, 2f);
        }
        UiKit.SetHoverColors(c.button, on ? UiKit.Brighten(UiKit.CardColor, 0.18f) : UiKit.CardColor);
    }

    void OnMoneyChanged(int value)
    {
        money = value;
        RefreshAffordability();
        if (hoveredCard != null && tipCost != null)
            tipCost.color = hoveredCard.data != null && hoveredCard.data.cost <= money ? UiKit.Gold : UiKit.Danger;
    }

    void RefreshAffordability()
    {
        foreach (var c in cards)
        {
            if (c == null || c.data == null) continue;
            bool ok = c.data.cost <= money;
            if (c.group != null) c.group.alpha = ok ? 1f : 0.45f;
            if (c.costText != null) c.costText.color = ok ? UiKit.Gold : UiKit.Danger;
        }
    }

    // ───────────────────────── convivencia con el HUD legacy ─────────────────────────

    /// <summary>
    /// Los botones Save/Load del BuildHUD viven a la misma altura que la barra; si quedan tapados
    /// se corren a la derecha en runtime (no se toca la escena).
    /// </summary>
    void NudgeLegacyButtons()
    {
        var canvas = GetComponentInParent<Canvas>();
        if (canvas == null) return;
        var canvasRT = canvas.rootCanvas.GetComponent<RectTransform>();
        if (canvasRT == null) return;

        Canvas.ForceUpdateCanvases();

        Rect canvasRect = canvasRT.rect;
        float barW = BarWidth();
        float barH = CardH + PadY * 2f;
        var barRect = new Rect(canvasRect.center.x - barW * 0.5f, canvasRect.yMin + BarBottom, barW, barH);

        string[] names = { "ButtonSave", "ButtonLoad", "ButtonUndo", "ButtonRedo" };
        var list = new List<RectTransform>();
        foreach (var n in names)
        {
            var t = UiKit.FindChildByName(canvasRT, n);
            if (t == null || !t.gameObject.activeInHierarchy) continue;
            if (t.IsChildOf(transform)) continue;
            var r = t as RectTransform;
            if (r != null) list.Add(r);
        }
        if (list.Count == 0) return;

        list.Sort((a, b) => LocalRect(canvasRT, a).xMin.CompareTo(LocalRect(canvasRT, b).xMin));

        float cursor = barRect.xMax + 16f;
        foreach (var r in list)
        {
            Rect lr = LocalRect(canvasRT, r);
            bool verticalOverlap = lr.yMax > barRect.yMin && lr.yMin < barRect.yMax;
            if (!verticalOverlap) continue;
            if (lr.xMax <= barRect.xMin) continue;            // a la izquierda: no molesta
            if (lr.xMin >= cursor) { cursor = lr.xMax + 16f; continue; }

            float dx = cursor - lr.xMin;
            r.anchoredPosition = r.anchoredPosition + new Vector2(dx, 0f);
            cursor = lr.xMax + dx + 16f;
        }
    }

    static Rect LocalRect(RectTransform canvasRT, RectTransform r)
    {
        var corners = new Vector3[4];
        r.GetWorldCorners(corners);
        Vector3 a = canvasRT.InverseTransformPoint(corners[0]);
        Vector3 b = canvasRT.InverseTransformPoint(corners[2]);
        return Rect.MinMaxRect(Mathf.Min(a.x, b.x), Mathf.Min(a.y, b.y), Mathf.Max(a.x, b.x), Mathf.Max(a.y, b.y));
    }
}
