using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// HUD superior de oleadas: nombre del nivel (se desvanece), "Oleada N / T", resumen de enemigos,
/// barra de cuenta regresiva con botón "¡Siguiente oleada!" (+bonus) y contador de enemigos.
/// También los toasts inferiores (oleada limpia, sin oro, lugar inválido). Todo con tiempo sin escalar.
/// </summary>
public class WaveHUD : MonoBehaviour
{
    const float BannerHold = 2.4f;
    const float BannerFade = 1.6f;
    const float ToastLife = 1.6f;
    const float ToastHeight = 36f;
    const float ToastGap = 6f;

    class ToastItem
    {
        public RectTransform rect;
        public CanvasGroup group;
        public float t;
    }

    LevelRuntime rt;
    RectTransform root;

    // banner
    CanvasGroup bannerGroup;
    float bannerTime;
    bool bannerDone;

    // panel
    Text waveText;
    Text summaryText;
    Image countdownFill;
    Text countdownText;
    Button nextButton;
    Text nextLabel;
    Text enemiesText;

    int shownWave;
    int totalWaves;
    int prepBonus;
    int shownBonus = -1;
    bool inPrep;
    bool finished;

    // toasts
    RectTransform toastRoot;
    readonly List<ToastItem> toasts = new List<ToastItem>();

    public static WaveHUD Create(LevelRuntime rt, RectTransform root)
    {
        if (rt == null || root == null) return null;
        var container = UiKit.CreateRect("WaveHUD", root);
        UiKit.SetFullscreen(container);
        var hud = container.gameObject.AddComponent<WaveHUD>();
        hud.Init(rt, root);
        return hud;
    }

    TowerPlacer placer;   // el placer es persistente entre escenas: se guarda para desuscribirse siempre

    void Init(LevelRuntime runtime, RectTransform parent)
    {
        rt = runtime;
        root = parent;

        BuildBanner();
        BuildPanel();
        BuildToastRoot();

        LevelEvents.WaveCountdown += OnCountdown;
        LevelEvents.WavePrepStarted += OnPrepStarted;
        LevelEvents.WaveStarted += OnWaveStarted;
        LevelEvents.WaveCleared += OnWaveCleared;
        LevelEvents.EnemiesChanged += OnEnemiesChanged;
        LevelEvents.LevelFinished += OnLevelFinished;
        placer = rt.Placer;
        if (placer != null) placer.OnPlacementRejected += OnPlacementRejected;

        SeedFromSpawner();
    }

    void OnDestroy()
    {
        LevelEvents.WaveCountdown -= OnCountdown;
        LevelEvents.WavePrepStarted -= OnPrepStarted;
        LevelEvents.WaveStarted -= OnWaveStarted;
        LevelEvents.WaveCleared -= OnWaveCleared;
        LevelEvents.EnemiesChanged -= OnEnemiesChanged;
        LevelEvents.LevelFinished -= OnLevelFinished;
        if (placer != null) placer.OnPlacementRejected -= OnPlacementRejected;
    }

    // ───────────────────────── construcción ─────────────────────────

    void BuildBanner()
    {
        var banner = UiKit.CreateRect("LevelBanner", transform);
        UiKit.Place(banner, UiKit.TopCenter, UiKit.TopCenter, new Vector2(0f, -215f), new Vector2(1000f, 130f));
        bannerGroup = UiKit.Group(banner.gameObject);
        bannerGroup.blocksRaycasts = false;
        bannerGroup.interactable = false;

        string name = rt.Level != null ? rt.Level.displayName : "Nivel";
        string subtitle = rt.Level != null ? rt.Level.subtitle : string.Empty;
        Color fam = rt.Level != null ? DefensePalette.Family(rt.Level.family) : UiKit.Gold;

        var title = UiKit.CreateText("Title", banner, name, 52, UiKit.Gold, TextAnchor.MiddleCenter, FontStyle.Bold);
        UiKit.StretchTop(title.rectTransform, 0f, 70f, 0f, 0f);
        UiKit.AddShadow(title.gameObject, new Color(0f, 0f, 0f, 0.85f), new Vector2(3f, -3f));
        UiKit.BestFit(title, 24, 52);

        var sub = UiKit.CreateText("Subtitle", banner, subtitle, 22, Color.white, TextAnchor.MiddleCenter, FontStyle.Normal);
        UiKit.StretchTop(sub.rectTransform, 72f, 32f, 0f, 0f);
        UiKit.AddShadow(sub.gameObject, new Color(0f, 0f, 0f, 0.85f), new Vector2(2f, -2f));
        UiKit.BestFit(sub, 12, 22);

        var strip = UiKit.CreateImage("Strip", banner, fam, false);
        UiKit.Place(strip.rectTransform, UiKit.TopCenter, UiKit.TopCenter, new Vector2(0f, -108f), new Vector2(240f, 4f));
    }

    void BuildPanel()
    {
        var panel = UiKit.CreatePanel("WavePanel", transform, UiKit.PanelColor, 2f);
        var p = panel.rectTransform;
        UiKit.Place(p, UiKit.TopCenter, UiKit.TopCenter, new Vector2(0f, -46f), new Vector2(560f, 140f));

        waveText = UiKit.CreateText("Wave", p, "Oleada 1 / 1", 24, UiKit.TextColor, TextAnchor.MiddleCenter, FontStyle.Bold);
        UiKit.StretchTop(waveText.rectTransform, 8f, 30f, 12f, 12f);

        summaryText = UiKit.CreateText("Summary", p, string.Empty, 16, UiKit.MutedText, TextAnchor.MiddleCenter);
        UiKit.StretchTop(summaryText.rectTransform, 40f, 22f, 12f, 12f);
        UiKit.BestFit(summaryText, 10, 16);

        var barBg = UiKit.CreateImage("CountdownBg", p, new Color(1f, 1f, 1f, 0.10f), false);
        UiKit.Place(barBg.rectTransform, UiKit.TopLeft, UiKit.TopLeft, new Vector2(12f, -68f), new Vector2(330f, 28f));
        UiKit.AddOutline(barBg.gameObject, new Color(1f, 1f, 1f, 0.12f), 1f);

        countdownFill = UiKit.CreateImage("Fill", barBg.transform, UiKit.WithAlpha(UiKit.Gold, 0.85f), false);
        UiKit.Stretch(countdownFill.rectTransform, 2f, 2f, 2f, 2f);
        countdownFill.type = Image.Type.Filled;
        countdownFill.fillMethod = Image.FillMethod.Horizontal;
        countdownFill.fillOrigin = (int)Image.OriginHorizontal.Left;
        countdownFill.fillAmount = 0f;

        countdownText = UiKit.CreateText("CountdownText", barBg.transform, string.Empty, 15, UiKit.TextColor, TextAnchor.MiddleCenter, FontStyle.Bold);
        UiKit.Stretch(countdownText.rectTransform, 4f, 0f, 4f, 0f);
        UiKit.AddShadow(countdownText.gameObject, new Color(0f, 0f, 0f, 0.7f), new Vector2(1f, -1f));
        UiKit.BestFit(countdownText, 10, 15);

        nextButton = UiKit.CreateButton("NextWave", p, "¡Siguiente oleada!", OnNextWaveClicked, UiKit.ButtonAccent, 14, new Vector2(200f, 28f));
        UiKit.Place(nextButton.GetComponent<RectTransform>(), UiKit.TopRight, UiKit.TopRight, new Vector2(-12f, -68f), new Vector2(200f, 28f));
        nextLabel = UiKit.ButtonLabel(nextButton);

        enemiesText = UiKit.CreateText("Enemies", p, "Enemigos: vivos 0 · por venir 0", 16, UiKit.TextColor, TextAnchor.MiddleCenter);
        UiKit.StretchTop(enemiesText.rectTransform, 104f, 24f, 12f, 12f);
    }

    void BuildToastRoot()
    {
        toastRoot = UiKit.CreateRect("Toasts", transform);
        UiKit.Place(toastRoot, UiKit.BottomCenter, UiKit.BottomCenter, new Vector2(0f, TowerCatalogUI.BarTop + 14f), new Vector2(700f, 240f));
    }

    // ───────────────────────── estado inicial ─────────────────────────

    /// <summary>El spawner ya emitió los primeros eventos antes de que exista esta UI: se reconstruye el estado.</summary>
    void SeedFromSpawner()
    {
        var sp = rt.Spawner;
        int alive = 0, pending = 0;
        if (sp != null)
        {
            totalWaves = sp.TotalWaves;
            inPrep = sp.InPrep;
            shownWave = Mathf.Max(1, sp.WaveIndex + (sp.InPrep || sp.WaveIndex == 0 ? 1 : 0));
            alive = sp.EnemiesAlive;
            pending = sp.PendingToSpawn;
        }
        else
        {
            totalWaves = rt.Level != null ? rt.Level.WaveCount() : 0;
            shownWave = 1;
            inPrep = false;
        }

        prepBonus = GroupBonus(rt.Level, shownWave);
        SetWaveLine();
        summaryText.text = (inPrep ? "Próxima: " : string.Empty) + GroupSummary(rt.Level, shownWave);
        OnEnemiesChanged(alive, pending);

        if (inPrep && sp != null) OnCountdown(sp.PrepRemaining, Mathf.Max(sp.PrepRemaining, 0.01f));
        else SetCountdownIdle();
    }

    // ───────────────────────── helpers de nivel ─────────────────────────

    /// <summary>Primer WaveDef del grupo N (1-based), agrupando como el spawner (joinPrevious).</summary>
    static WaveDef FirstOfGroup(LevelDefinition level, int groupIndex1)
    {
        if (level == null || level.waves == null) return null;
        int g = 0;
        for (int i = 0; i < level.waves.Count; i++)
        {
            var w = level.waves[i];
            if (w == null) continue;
            if (i == 0 || !w.joinPrevious || g == 0) g++;
            if (g == groupIndex1) return w;
        }
        return null;
    }

    static int GroupBonus(LevelDefinition level, int groupIndex1)
    {
        var w = FirstOfGroup(level, groupIndex1);
        return w != null ? Mathf.Max(0, w.earlyCallBonus) : 0;
    }

    static string GroupSummary(LevelDefinition level, int groupIndex1)
    {
        if (level == null || level.waves == null) return string.Empty;
        var parts = new List<string>();
        int g = 0;
        for (int i = 0; i < level.waves.Count; i++)
        {
            var w = level.waves[i];
            if (w == null) continue;
            if (i == 0 || !w.joinPrevious || g == 0) g++;
            if (g == groupIndex1) parts.Add(w.count + " × " + EnemyNames.Of(w.enemyType));
            else if (g > groupIndex1) break;
        }
        return string.Join("  +  ", parts.ToArray());
    }

    // ───────────────────────── eventos ─────────────────────────

    void OnPrepStarted(int index, int total, string summary)
    {
        shownWave = index;
        totalWaves = total;
        inPrep = true;
        prepBonus = GroupBonus(rt.Level, index);
        shownBonus = -1;
        SetWaveLine();
        summaryText.text = "Próxima: " + summary;
    }

    void OnWaveStarted(int index, int total, string summary)
    {
        shownWave = index;
        totalWaves = total;
        inPrep = false;
        SetWaveLine();
        summaryText.text = summary;
        SetCountdownIdle();
    }

    void OnCountdown(float remaining, float total)
    {
        if (finished) return;
        if (remaining <= 0f)
        {
            inPrep = false;
            SetCountdownIdle();
            return;
        }
        inPrep = true;
        float f = total > 0f ? Mathf.Clamp01(remaining / total) : 0f;
        countdownFill.fillAmount = f;
        countdownText.text = "Próxima oleada en " + remaining.ToString("0.0") + " s";

        int bonusNow = prepBonus > 0 ? Mathf.RoundToInt(prepBonus * f) : 0;
        if (bonusNow != shownBonus)
        {
            shownBonus = bonusNow;
            if (nextLabel != null)
                nextLabel.text = bonusNow > 0 ? "¡Siguiente oleada!  +" + bonusNow + " oro" : "¡Siguiente oleada!";
        }
        if (!nextButton.gameObject.activeSelf) nextButton.gameObject.SetActive(true);
        nextButton.interactable = true;
    }

    void SetCountdownIdle()
    {
        countdownFill.fillAmount = 0f;
        countdownText.text = finished ? string.Empty : "Oleada en curso";
        shownBonus = -1;
        if (nextButton != null)
        {
            nextButton.interactable = false;
            nextButton.gameObject.SetActive(false);
        }
    }

    void SetWaveLine()
    {
        if (waveText == null) return;
        int t = Mathf.Max(totalWaves, shownWave);
        waveText.text = "Oleada " + shownWave + " / " + t;
    }

    void OnWaveCleared(int index, int bonus)
    {
        if (bonus > 0) Toast("Oleada limpia  +" + bonus + " oro", UiKit.Gold);
    }

    void OnEnemiesChanged(int alive, int pending)
    {
        if (enemiesText == null) return;
        enemiesText.text = "Enemigos: vivos " + Mathf.Max(0, alive) + " · por venir " + Mathf.Max(0, pending);
    }

    void OnLevelFinished(LevelDefinition level, bool won)
    {
        finished = true;
        inPrep = false;
        if (waveText != null) waveText.text = won ? "¡Nivel superado!" : "Nivel perdido";
        if (summaryText != null) summaryText.text = string.Empty;
        SetCountdownIdle();
    }

    void OnPlacementRejected(Vector3 position)
    {
        int cost = rt.Placer != null ? rt.Placer.SelectedCost : 0;
        if (cost <= 0 && rt.Placer != null && rt.Placer.SelectedData != null) cost = rt.Placer.SelectedData.cost;
        int money = GameManager.I != null ? GameManager.I.Money : int.MaxValue;
        if (money < cost) Toast("Sin oro suficiente", UiKit.Danger);
        else Toast("No se puede construir ahí", UiKit.Danger);
    }

    void OnNextWaveClicked()
    {
        UiKit.ClearSelection();
        CallNextWave();
    }

    void CallNextWave()
    {
        if (rt == null || rt.Spawner == null || rt.IsPaused || finished) return;
        rt.Spawner.CallNextWaveEarly();
    }

    // ───────────────────────── update ─────────────────────────

    void Update()
    {
        float dt = Time.unscaledDeltaTime;
        UpdateBanner(dt);
        UpdateToasts(dt);

        if (!finished && rt != null && !rt.IsPaused && Input.GetKeyDown(KeyCode.Space) && !UiKit.IsTyping())
            CallNextWave();

        // seguridad: si el spawner dejó la preparación sin avisar, apagar la barra
        if (inPrep && rt != null && rt.Spawner != null && !rt.Spawner.InPrep && !finished)
        {
            inPrep = false;
            SetCountdownIdle();
        }
    }

    void UpdateBanner(float dt)
    {
        if (bannerDone || bannerGroup == null) return;
        bannerTime += dt;
        float a = 1f;
        if (bannerTime > BannerHold) a = 1f - Mathf.Clamp01((bannerTime - BannerHold) / BannerFade);
        bannerGroup.alpha = a;
        if (bannerTime >= BannerHold + BannerFade)
        {
            bannerDone = true;
            bannerGroup.gameObject.SetActive(false);
        }
    }

    // ───────────────────────── toasts ─────────────────────────

    public void Toast(string message, Color color)
    {
        if (toastRoot == null || string.IsNullOrEmpty(message)) return;

        var panel = UiKit.CreatePanel("Toast", toastRoot, UiKit.PanelStrong, 1.5f, false);
        var txt = UiKit.CreateText("Label", panel.transform, message, 18, color, TextAnchor.MiddleCenter, FontStyle.Bold);
        UiKit.Stretch(txt.rectTransform, 14f, 2f, 14f, 2f);
        txt.horizontalOverflow = HorizontalWrapMode.Overflow;
        txt.verticalOverflow = VerticalWrapMode.Overflow;

        float w = Mathf.Clamp(txt.preferredWidth + 40f, 180f, 680f);
        UiKit.Place(panel.rectTransform, UiKit.BottomCenter, UiKit.BottomCenter, new Vector2(0f, 0f), new Vector2(w, ToastHeight));

        var g = UiKit.Group(panel.gameObject);
        g.alpha = 0f;
        g.blocksRaycasts = false;
        g.interactable = false;

        var item = new ToastItem();
        item.rect = panel.rectTransform;
        item.group = g;
        item.t = 0f;
        toasts.Insert(0, item);

        while (toasts.Count > 5)
        {
            var old = toasts[toasts.Count - 1];
            toasts.RemoveAt(toasts.Count - 1);
            if (old.rect != null) Destroy(old.rect.gameObject);
        }
    }

    void UpdateToasts(float dt)
    {
        for (int i = toasts.Count - 1; i >= 0; i--)
        {
            var it = toasts[i];
            if (it.rect == null) { toasts.RemoveAt(i); continue; }
            it.t += dt;

            float a;
            if (it.t < 0.15f) a = it.t / 0.15f;
            else if (it.t > ToastLife - 0.5f) a = Mathf.Clamp01((ToastLife - it.t) / 0.5f);
            else a = 1f;
            it.group.alpha = a;

            float targetY = i * (ToastHeight + ToastGap);
            Vector2 p = it.rect.anchoredPosition;
            p.y = Mathf.Lerp(p.y, targetY, 1f - Mathf.Exp(-14f * dt));
            it.rect.anchoredPosition = p;

            if (it.t >= ToastLife)
            {
                toasts.RemoveAt(i);
                Destroy(it.rect.gameObject);
            }
        }
    }
}
