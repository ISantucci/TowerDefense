#!/bin/bash
set -u
PKG="$1"; DEST="$2"
cd "$DEST" || exit 1
tar tzf "$PKG" | grep -v '/$' | grep '^Assets/' | while read -r f; do
  d=$(dirname "$f"); mkdir -p "$d"
  if [ -e "$f" ]; then tar xzOf "$PKG" "$f" > "$f" && echo "upd $f"; else tar xzf "$PKG" "$f" && echo "new $f"; fi
done
